<script src="https://accounts.google.com/gsi/client" async defer></script>

<!-- Cấu hình Google One Tap -->
<div id="g_id_onload" data-client_id="479761304566-lv0pgsc1tfgpfd9u0u34uok23jdo9jcn.apps.googleusercontent.com"
    data-login_uri="https://toanhongkorean.com/auth/google/one-tap" data-auto_prompt="true">
</div>

<script>
    // 1. Định nghĩa hàm xử lý kết quả TRƯỚC (Đưa ra global bằng window.)
    window.handleCredentialResponse = function(response) {
        console.log("Đã nhận được phản hồi từ Google:");
        console.log(response);

        // Thông thường ở đây bạn sẽ gửi token này về server Laravel để xử lý login
        // Ví dụ dùng thẻ form ẩn hoặc fetch API để gửi response.credential
    };

    // 2. Lệnh khởi chạy khi trang web tải xong
    window.onload = function() {
        if (typeof google !== 'undefined') {
            google.accounts.id.initialize({
                client_id: "479761304566-lv0pgsc1tfgpfd9u0u34uok23jdo9jcn.apps.googleusercontent.com",
                callback: window.handleCredentialResponse // Trỏ đúng vào hàm global ở trên
            });
            google.accounts.id.prompt(); // Hiện bảng One Tap của Google
        }
    };
</script>
